class Wizard:
    def __init__(self, name, rating, age_appearance):
        self.name = name
        self.rating = rating
        self.age_appearance = age_appearance

    def change_rating(self, value):
        if value > 0:
            if self.rating + value <= 100:
                self.rating += value
                if self.age_appearance - abs(value) // 10 > 18:
                    self.age_appearance -= abs(value) // 10
                else:
                    self.age_appearance = 18
        elif value < 0:
            if self.rating + value >= 1:
                self.rating += value
                self.age_appearance -= abs(value) // 10

    def __iadd__(self, string):
        self.rating += len(string)
        if self.age_appearance - len(string) // 10 > 18:
            self.age_appearance -= len(string) // 10
        else:
            self.age_appearance = 18
        return self

    def __call__(self, number):
        return (number - self.age_appearance) * self.rating

    def __str__(self):
        return f"Wizard {self.name} with {self.rating} rating looks {self.age_appearance} years old"

    def __lt__(self, other):
        if self.rating != other.rating:
            return self.rating < other.rating
        elif self.age_appearance != other.age_appearance:
            return self.age_appearance < other.age_appearance
        else:
            return self.name < other.name

    def __gt__(self, other):
        if self.rating != other.rating:
            return self.rating > other.rating
        elif self.age_appearance != other.age_appearance:
            return self.age_appearance > other.age_appearance
        else:
            return self.name > other.name

    def __le__(self, other):
        return self.__lt__(other) or self.__eq__(other)

    def __ge__(self, other):
        return self.__gt__(other) or self.__eq__(other)

    def __eq__(self, other):
        return self.rating == other.rating and self.age_appearance == other.age_appearance and self.name == other.name

    def __ne__(self, other):
        return not self.__eq__(other)


# Пример

w1 = Wizard("Gandalf", 90, 70)

w1.change_rating(20)
print(w1.rating)  # 100
print(w1.age_appearance)  # 68

w1 += "Powerful Wizard"
print(w1.rating)  # 117
print(w1.age_appearance)  # 66

result = w1(10)
print(result)  # 510

print(w1)

w2 = Wizard("Merlin", 85, 60)
print(w1 > w2)
print(w1 == w2)
