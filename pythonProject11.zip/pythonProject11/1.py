class AirCastle:
    def __init__(self, height, num_clouds, color):
        self.height = height
        self.num_clouds = num_clouds
        self.color = color

    def change_height(self, value):
        if self.height - value >= 0:
            self.height -= value
        else:
            self.height = 0

    def __add__(self, n):
        self.num_clouds += n
        self.height += n // 5

    def __call__(self, transparency):
        visibility = self.height // transparency * self.num_clouds
        return visibility

    def __str__(self):
        return f"The AirCastle at an altitude of {self.height} meters is {self.color} with {self.num_clouds} clouds"

    def __gt__(self, other):
        if self.num_clouds > other.num_clouds:
            return True
        elif self.num_clouds == other.num_clouds:
            if self.height > other.height:
                return True
            elif self.height == other.height:
                return self.color > other.color
        return False

    def __lt__(self, other):
        if self.num_clouds < other.num_clouds:
            return True
        elif self.num_clouds == other.num_clouds:
            if self.height < other.height:
                return True
            elif self.height == other.height:
                return self.color < other.color
        return False

    def __ge__(self, other):
        return self.__gt__(other) or self.__eq__(other)

    def __le__(self, other):
        return self.__lt__(other) or self.__eq__(other)

    def __eq__(self, other):
        return self.num_clouds == other.num_clouds and self.height == other.height and self.color == other.color

    def __ne__(self, other):
        return not self.__eq__(other)


# Пример

castle1 = AirCastle(100, 3, "Blue")
castle1.change_height(50)
castle1 + 7
print(castle1)

visibility = castle1(10)
print(visibility)

castle2 = AirCastle(80, 5, "Green")

if castle1 > castle2:
    print("Castle 1 is greater than Castle 2")
elif castle1 < castle2:
    print("Castle 1 is smaller than Castle 2")
else:
    print("Castle 1 is equal to Castle 2")